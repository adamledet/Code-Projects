﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionDetection : MonoBehaviour {

    //Object / Component References
    public GameObject player;
    public List<GameObject> objects;
    public List<GameObject> bullets;
    SpriteRenderer pSprite;
    SpriteRenderer oSprite;

    //Distance Components
    Vector3 playerVectorMin;
    Vector3 playerVectorMax;
    Vector3 objectVectorMin;
    Vector3 objectVectorMax;
    float pRad;
    float oRad;
    Vector3 distance;


    // Use this for initialization
    void Start()
    {
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Keep player color constant
        player.GetComponent<SpriteRenderer>().color = new Color(255, 255, 255);

        //Check for Player Collisions /w/ asteroids
        for (int i = 0; i < objects.Count; i++)
        {
            if (CircleDetection(player, objects[i]))
            {
                player.GetComponent<SpriteRenderer>().color = new Color(255, 0, 0);
                objects[i].GetComponent<AsteroidMovement>().destroyed = true;
                GameObject.Find("SceneManager").GetComponent<Score>().lives -= 1;
                if (GameObject.Find("SceneManager").GetComponent<Score>().lives <= 0)//No lives left
                {
                    //Set all things relevant inactive
                    player.SetActive(false);
                    this.gameObject.GetComponent<CollisionDetection>().enabled = false;
                    objects[i].SetActive(false);
                }
            }
        }
        if (bullets.Count > 0)//Check for bullet collision iff there are bullets in the List
        {
            for (int i = 0; i < bullets.Count; i++)
            {
                for (int j = 0; j < objects.Count; j++)
                {
                    if (CircleDetection(bullets[i], objects[j]))
                    {
                        bullets[i].GetComponent<BulletMovement>().destroyed = true;
                        objects[j].GetComponent<AsteroidMovement>().destroyed = true;
                    }
                }
            }
        }


    }

    //Circle Detection
    public bool CircleDetection(GameObject p, GameObject o)
    {
        pRad = p.GetComponent<CircleCollider2D>().radius;
        oRad = (o.GetComponent<CircleCollider2D>().radius * o.transform.localScale.x);

        distance = p.transform.position - o.transform.position;
        //Collision
        if ((pRad + oRad) > distance.magnitude)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //GUI
    void OnGUI()
    {
        GUI.Box(new Rect(Screen.width / 10, Screen.height / 20, 150, 75), "Controls:\nArrow Keys to move\nSpacebar to Shoot");
    }
}
