﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score : MonoBehaviour {

    public int lives;
    public int score;

	// Use this for initialization
	void Start ()
    {
        //Default number of lives
        if(lives <= 0)
        {
            lives = 3;
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void OnGUI()
    {
        if(lives > 0)
        {
            GUI.Box(new Rect((Screen.width - (Screen.width / 10)), (Screen.height / 20), 150, 50), "Lives: " + lives + "\nScore: " + score);
        }
        else
        {
            GUI.Box(new Rect((Screen.width / 2) - 150, (Screen.height / 2) - 50, 150, 50), "Game Over" + "\nFinal Score: " + score);
        }
    }
}
