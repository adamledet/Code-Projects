﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletMovement : MonoBehaviour {
    
    public Vector3 velocity;
    public bool destroyed;

	// Use this for initialization
	void Start ()
    {
        velocity = velocity / 3;
        GameObject.Find("SceneManager").GetComponent<CollisionDetection>().bullets.Add(this.gameObject);
        destroyed = false;
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Move Bullet
        transform.position += velocity;


        //Destroy bullet after it exceeds bounds and remove it from the collision detection list
        //X
        if (transform.position.x >= 9.3)
        {
            DestroySelf();
        }
        else if (transform.position.x <= -9.3)
        {
            DestroySelf();
        }

        //Y
        if (transform.position.y >= 5.5)
        {
            DestroySelf();
        }
        else if (transform.position.y <= -5.5)
        {
            DestroySelf();
        }

        if (destroyed == true)
        {
            DestroySelf();
        }
    }

    void DestroySelf()
    {
        GameObject.Find("SceneManager").GetComponent<CollisionDetection>().bullets.Remove(this.gameObject);
        Destroy(this.gameObject);
    }
}
