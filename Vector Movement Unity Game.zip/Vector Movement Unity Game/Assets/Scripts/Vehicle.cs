﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour {

    //Using the below tag, you can make a private variable able to be edited using the inspector.
    //[SerializeField]
    public Vector3 position;
    public float speed;         //0.05f
    //public Vector3 speed;
    public Vector3 direction;
    public Vector3 velocity;

    //For Rotation
    public float anglePerFrame;
    Quaternion angle;
    float totalRotation;

    //For acceleration
    public Vector3 acceleration;
    public float maxSpeed;
    public float accelRate;

    //Bullet GameObject
    public GameObject bullet;

    //Scene Manager
    public GameObject sceneManager;


    // Use this for initialization
    void Start ()
    {
        position = transform.position;
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Step 1: add "speed" to position
        //position.x += speed;
        //position.y += speed;

        //Step 2: use speed as a Vector
        //position.x += speed.x;
        //position.y += speed.y;
        //OR
        //position += speed;

        //Step 3: Calculate Velocity = speed * direction
        //direction.Normalize();//normalize the direction Vector so that its magnitude is always 1.
        //velocity = speed * direction;
        //position += velocity;

        //Step 4: Use Acceleration
        if (Input.GetKey(KeyCode.UpArrow))//Forwards
        {
            acceleration = accelRate * direction;
        }
        else if (Input.GetKey(KeyCode.DownArrow))//Backwards
        {
            acceleration = (-accelRate) * direction;
        }
        else//Decelerate
        {
            velocity = velocity * 29 / 30;
            acceleration = acceleration * 0;
            if (velocity.magnitude <= .001)
            {
                velocity = velocity * 0;
            }
        }
        velocity += acceleration;
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);//Limit the speed
        position += velocity;
        //Debug.Log("Velocity Magnitude: " + velocity.magnitude);
   

        //Rotate the Vehicle on user's input
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            angle = Quaternion.Euler(0, 0, anglePerFrame);
            direction = (angle * direction);
            totalRotation += anglePerFrame;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            angle = Quaternion.Euler(0, 0, -anglePerFrame);
            direction = (angle * direction);
            totalRotation -= anglePerFrame;
        }

        //Screen Wrap
        //X
        if(position.x >= 9.3)
        {
            position.x = -9f;
        }
        else if(position.x <= -9.3)
        {
            position.x = 9f;
        }

        //Y
        if (position.y >= 5.5)
        {
            position.y = -5.2f;
        }
        else if (position.y <= -5.5)
        {
            position.y = 5.2f;
        }


        //Update the prefab's position;
        transform.position = position;
        transform.rotation = Quaternion.Euler(0, 0, totalRotation - 90);//-90 tailors to this exact Sprite used.


        //Shoot (limited to 3 shots)
        if(GameObject.Find("SceneManager").GetComponent<CollisionDetection>().bullets.Count <= 2)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Fire(bullet);
            }
        }

	}

    public void Fire(GameObject b)
    {
        //Create the bullet and add it to the bullets array in Collision Detection
        GameObject newBullet = b;
        newBullet.GetComponent<BulletMovement>().velocity = direction;
        newBullet.transform.position = position;
        Instantiate(newBullet);
    }
}
